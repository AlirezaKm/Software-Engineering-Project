import {
    colors,
    textStyle,
    appNameStyle,
    textShadow
} from './mutual'


module.exports={    
    colors,
    textStyle,
    appNameStyle,
    textShadow
};