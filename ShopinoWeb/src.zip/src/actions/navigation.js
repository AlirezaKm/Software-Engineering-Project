import {NavigationActions} from 'react-navigation'

export const back= ()=>{
    const backAction = NavigationActions.back();
    
}