const tables = {
    login:'login',
    users:'users',
    factors:'factors',
    categories:'categories',
    subcategories:'subcategories',
    properties:'properties',
    products:'products',
    postproducts:'postproducts',
    orderFactors:'orderfactors',
    orders:'orders',
    expenses:'expenses',
    productProperties:'productproperties'
}
export default  tables